<?php

namespace App\Controllers;

use App\Models\CommonModel;
use Codeigniter\API\ResponseTrait;

class Home extends BaseController
{
    use ResponseTrait;
    private $model;

    public function __construct()
    {
        $this->model = new CommonModel();
    }

    public function index($id = null)
    { 
        if ($id == null) {

            $fetchRecord = $this->model->selectRecord("user");
         
        $result = [
            "status" => 201,
            "data" => $fetchRecord,
        ];

        } else {
            $fetchRecord = $this->model->selectRow("user", ["id" => $id]);
         
            if(!empty($fetchRecord)) {

                $result = [
                    "status" => 201,
                    "data" => $fetchRecord,
                ];

            } else{
                $result = [
                    "status" => 404,
                    "data" => "No Record Found",
                ];
            }
        }
        return $this->respond($result);
    }

public function delete($id) 
{
    $selectData = $this->model->selectRow("user", ["id" => $id]);


    if(!empty($selectData)){
        $delete = $this->model->deleteValue("user", ["id" => $id]);
    
        if($delete) {
        $result = [
            "status" => 201,
            "data" => "Well deleted",
        ];
    } else {
        $result = [
            "status" => 404,
            "data" => "Error found at deletion",
        ];
    } 

    }


else {
    $result = [
        "status" => 404,
        "data" => "No Record Found to delete",
    ];

    }
    return $this->respond($result);
}


//now for the status
public function status($id, $status) 
{
    $selectData = $this->model->selectRow("user", ["id" => $id]);


    if(!empty($selectData)){
    
    if($status === "Active") {
        $action = 'Inactive';
    }   else {
        $action = 'Active';
    }
    $data = [
        "status" => $action
    ];

    $updateStatus = $this->model->updateValue("user", ["id" => $id], $data);
    
    if($updateStatus) {
        $result = [
            "status" => 201,
            "data" => "Update status sucessfully",
        ];
    } else {
        $result = [
            "status" => 404,
            "data" => "Error found at update",
        ];
    } 


    } else {
    $result = [
        "status" => 404, 
        "data" => "No Record Found to update",
    ];

    }
    return $this->respond($result);
}

}

